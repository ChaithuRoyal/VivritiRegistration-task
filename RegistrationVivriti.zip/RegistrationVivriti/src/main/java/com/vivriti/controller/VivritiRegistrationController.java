package com.vivriti.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.vivriti.entity.VivritiRegistration;
import com.vivriti.service.VivritiRegistrationService;

/**
 * @author nagsa
 *
 */
@RestController
public class VivritiRegistrationController {

	@Autowired
	private VivritiRegistrationService vivritiRegistrationService;

	/**
	 * @param vivritiRegistration
	 * @return vivritiRegistration
	 */
	@PostMapping("/vivritiRegistration")

	public VivritiRegistration saveVivritiRegistration(

			@Validated @RequestBody VivritiRegistration vivritiRegistration)

	{

		return vivritiRegistration.saveVivritiRegistration(vivritiRegistration);

	}

	/**
	 * @return list
	 */
	@GetMapping("/vivritiRegistration")

	public List<VivritiRegistration> fetchVivritiRegistrationList()

	{

		return vivritiRegistrationService.fetchVivritiRegistrationList();

	}

	/**
	 * @param vivritiRegistration
	 * @param vivritiRegistrationId
	 * @return vivritiRegistration
	 */
	@PutMapping("/vivritiRegistration/{id}")

	public VivritiRegistration

			updateVivritiRegistration(@RequestBody VivritiRegistration vivritiRegistration,

					@PathVariable("id") Long vivritiRegistrationId)

	{

		return vivritiRegistrationService.updateVivritiRegistration(

				vivritiRegistration, vivritiRegistrationId);

	}

	/**
	 * @param vivritiRegistrationId
	 * @return vivritiRegistrationId
	 */
	// Delete operation

	@DeleteMapping("/vivritiRegistration/{id}")

	public String deleteVivritiRegistrationById(@PathVariable("id") Long vivritiRegistrationId)

	{

		vivritiRegistrationService.deleteVivritiRegistrationById(

				vivritiRegistrationId);

		return "Deleted Successfully";

	}
}
