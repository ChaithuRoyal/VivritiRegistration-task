package com.vivriti.service;

import java.util.List;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;

import com.vivriti.entity.VivritiRegistration;
import com.vivriti.repository.VivritiRegistrationRepository;

/**
 * @author nagsa
 *
 */
public class VivritiRegistrationServiceImpl implements VivritiRegistrationService {
	@Autowired

	private VivritiRegistrationRepository vivritiRegistrationRepository;

	@Override
	public VivritiRegistration saveVivritiRegistration(VivritiRegistration vivritiRegistration) {
		//
		return vivritiRegistrationRepository.save(vivritiRegistration);

	}

	@Override
	public List<VivritiRegistration> fetchVivritiRegistrationList() {
		return (List<VivritiRegistration>)

		vivritiRegistrationRepository.findAll();

	}

	@Override
	public VivritiRegistration updateVivritiRegistration(VivritiRegistration vivritiRegistration,
			Long VivritiRegistrationId) {
		VivritiRegistration registrationDB = vivritiRegistrationRepository.findById(VivritiRegistrationId)

				.get();

		if (Objects.nonNull(VivritiRegistration.getVivritiRegistrationUserName())

				&& !"".equalsIgnoreCase(

						(String) vivritiRegistration.getVivritiRegistrationUserName())) {

			registrationDB.setVivritiRegistrationUserName(

					vivritiRegistration.getVivritiRegistrationUserName());

		}
		if (Objects.nonNull(VivritiRegistration.getVivritiRegistrationFirstName())

				&& !"".equalsIgnoreCase(

						(String) vivritiRegistration.getVivritiRegistrationFirstName())) {

			registrationDB.setVivritiRegistrationUserName(

					vivritiRegistration.getVivritiRegistrationFirstName());

		}
		if (Objects.nonNull(VivritiRegistration.getVivritiRegistrationLastName())

				&& !"".equalsIgnoreCase(

						(String) vivritiRegistration.getVivritiRegistrationLastName())) {

			registrationDB.setVivritiRegistrationUserName(

					vivritiRegistration.getVivritiRegistrationLatName());

		}

		if (Objects.nonNull(

				VivritiRegistration.getVivritiRegistrationPassword())

				&& !"".equalsIgnoreCase(

						(String) vivritiRegistration.getVivritiRegistrationPassword())) {

			registrationDB.setVivritiRegistrationPassword(

					vivritiRegistration.getVivritiRegistrationPassword());

		}

		if (Objects.nonNull(VivritiRegistration.getVivritiRegistrationdoj())

				&& !"".equalsIgnoreCase(

						(String) vivritiRegistration.getVivritiRegistrationdoj())) {

			registrationDB.setVivritiRegistrationdoj(

					vivritiRegistration.getVivritiRegistrationdoj());

		}

		return vivritiRegistrationRepository.save(registrationDB);

	}

	@Override
	public void deleteVivritiRegistrationById(Long VivritiRegistrationId) {
		vivritiRegistrationRepository.deleteById(VivritiRegistrationId);

	}

}
