package com.vivriti.service;

import java.util.List;

import com.vivriti.entity.VivritiRegistration;

/**
 * @author nagsa
 *
 */
public interface VivritiRegistrationService {
	/**
	 * @param vivritiRegistration
	 * @param department
	 * @return VivritiRegistration
	 */
	// Save operation

	VivritiRegistration saveVivritiRegistration(VivritiRegistration vivritiRegistration);

	/**
	 * @return VivritiRegistration
	 */
	// Read operation

	List<VivritiRegistration> fetchVivritiRegistrationList();

	/**
	 * @param vivritiRegistration
	 * @param VivritiRegistrationId
	 * @return vivritiRegistration
	 */
	// Update operation

	VivritiRegistration updateVivritiRegistration(VivritiRegistration vivritiRegistration,

			Long VivritiRegistrationId);

	/**
	 * @param VivritiRegistrationId
	 */
	// Delete operation

	void deleteVivritiRegistrationById(Long VivritiRegistrationId);
}
