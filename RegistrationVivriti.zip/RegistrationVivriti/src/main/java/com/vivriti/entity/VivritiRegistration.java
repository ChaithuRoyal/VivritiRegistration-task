package com.vivriti.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author nagsa
 *
 */
@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class VivritiRegistration {
	@Id

	@GeneratedValue(strategy = GenerationType.AUTO)
	private String userName;
	private String password;
	private String firstName;
	private String lastName;
	@Column(name = "DOJ")
	private static Date doj;

	/**
	 * @return object
	 */
	public static Object getVivritiRegistrationUserName() {
		try {

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return doj;

	}

	/**
	 * @param vivritiRegistrationUserName
	 */
	public void setVivritiRegistrationUserName(Object vivritiRegistrationUserName) {
		// TODO Auto-generated method stub

	}

	/**
	 * @return password
	 */
	public static Object getVivritiRegistrationPassword() {
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * @param vivritiRegistrationPassword
	 */
	public void setVivritiRegistrationPassword(Object vivritiRegistrationPassword) {
		// TODO Auto-generated method stub

	}

	/**
	 * @return firstName
	 */
	public static Object getVivritiRegistrationFirstName() {
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * @return LastNmae
	 */
	public static Object getVivritiRegistrationLastName() {
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * @return LastName
	 */
	public Object getVivritiRegistrationLatName() {
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * @return doj
	 */
	public static Object getVivritiRegistrationdoj() {
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * @param vivritiRegistrationdoj
	 */
	public void setVivritiRegistrationdoj(Object vivritiRegistrationdoj) {
		// TODO Auto-generated method stub

	}

	/**
	 * @param vivritiRegistration
	 * @return vivritiRegistration
	 */
	public VivritiRegistration saveVivritiRegistration(VivritiRegistration vivritiRegistration) {
		// TODO Auto-generated method stub
		return null;
	}

}
