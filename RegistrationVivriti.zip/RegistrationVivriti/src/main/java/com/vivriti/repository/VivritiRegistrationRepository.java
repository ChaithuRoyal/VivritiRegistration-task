package com.vivriti.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.vivriti.entity.VivritiRegistration;

/**
 * @author nagsa
 *
 */
@Repository
public interface VivritiRegistrationRepository extends CrudRepository<VivritiRegistration, Long> {

}
