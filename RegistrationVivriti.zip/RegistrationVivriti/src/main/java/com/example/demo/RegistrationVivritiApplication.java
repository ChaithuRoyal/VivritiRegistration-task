package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * @author nagsa
 *
 */
@SpringBootApplication
public class RegistrationVivritiApplication {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		SpringApplication.run(RegistrationVivritiApplication.class, args);
		System.out.println("Test");
	}

}
