package com.example.demo.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.User;
import com.example.demo.repository.UserRepository;

/**
 * @author nagsa
 *
 */
@Service
public class UserService {

	@Autowired
	private UserRepository userRepository;

	/**
	 * @param user
	 * @return user
	 */
	public int register(User user) {

		user = userRepository.save(user);
		return user.getUserId();
	}

	/**
	 * @param userId
	 * @return user
	 */
	public User update(int userId) {
		return userRepository.findById(userId).get();
	}

	/**
	 * @param userId
	 * @return user
	 */
	public User delete(int userId) {
		Optional<User> optional = userRepository.findById(userId);

		if (optional.isEmpty()) {
			return null;
		}

		userRepository.deleteById(userId);
		return optional.get();
	}

	/**
	 * @param userId
	 * @return user
	 */
	public User getUser(int userId) {
		return userRepository.findById(userId).get();

	}
}
