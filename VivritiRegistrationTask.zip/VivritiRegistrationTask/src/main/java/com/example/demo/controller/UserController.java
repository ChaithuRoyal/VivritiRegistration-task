package com.example.demo.controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.User;
import com.example.demo.service.UserService;

/**
 * @author nagsa
 *
 */
@RestController
@SuppressWarnings("deprecation")
public class UserController {

	@Autowired
	private UserService userService;

	/**
	 * @param username
	 * @param password
	 * @param firstName
	 * @param lastName
	 * @param dob
	 * @return userId
	 * @throws ParseException
	 */
	@PostMapping("/register/{username}/{password}/{firstName}/{lastName}/{dob}")
	public int register(@PathVariable String username, @PathVariable String password, @PathVariable String firstName,
			@PathVariable String lastName, @PathVariable String dob) throws ParseException {

		Date dateOfBirth = new SimpleDateFormat("dd-MM-yyyy").parse(dob);
		int userId = userService.register(new User(username, password, firstName, lastName, dateOfBirth));
		return userId;
	}

	/**
	 * @param userId
	 * @return userId
	 */
	@GetMapping("/get/{userId}")
	public User get(@PathVariable int userId) {
		return userService.getUser(userId);
	}

	/**
	 * @param userId
	 * @return userId
	 */
	@PatchMapping("/update/{userId}")
	public User update(@PathVariable int userId) {
		return userService.update(userId);
	}

	/**
	 * @param userId
	 * @return userId
	 */
	@DeleteMapping("/delete/{userId}")
	public User delete(@PathVariable int userId) {
		return userService.delete(userId);
	}
}
