package com.vivriti.Average;

import java.util.ArrayList;

public class ListAverage {

	public static void main(String[] args) {
		ArrayList<Integer>arrayList = new ArrayList<Integer>();
		arrayList.add(10);
		arrayList.add(100);
		arrayList.add(100);
		arrayList.add(1000);
		arrayList.add(10000);
		arrayList.add(100000);
		arrayList.add(1000000);
		arrayList.add(10000000);
		double sum = 0.0;
		
		for(int num:arrayList) {
			sum = sum+num;
		}

		double average = (sum/arrayList.size());
		System.out.println("Average of list of Integers = "+average);
		
	}

}
